# utils/reddit_scraper.py

import praw
import os

def scrape_user_content(username):
    reddit = praw.Reddit(
        client_id=os.getenv("REDDIT_CLIENT_ID"),
        client_secret=os.getenv("REDDIT_CLIENT_SECRET"),
        user_agent=os.getenv("REDDIT_USER_AGENT"),
    )

    user = reddit.redditor(username)

    comments = []
    for comment in user.comments.new(limit=100):
        comments.append(f"[Comment in r/{comment.subreddit}]: {comment.body}")

    posts = []
    for submission in user.submissions.new(limit=100):
        post_text = submission.title + "\n" + (submission.selftext or "")
        posts.append(f"[Post in r/{submission.subreddit}]: {post_text}")

    return comments, posts
