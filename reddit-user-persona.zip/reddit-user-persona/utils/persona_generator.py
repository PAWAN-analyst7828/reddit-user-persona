# utils/persona_generator.py

import openai
import os

def generate_persona(username, comments, posts):
    openai.api_key = os.getenv("OPENAI_API_KEY")

    combined_text = "\n".join(posts + comments)
    input_text = combined_text[:15000]  # Truncate to fit GPT token limit

    prompt = f"""
You are a social behavior analyst. Based on the following Reddit activity by u/{username}, generate a structured User Persona.

Include:
- Name (guess if not mentioned)
- Age
- Location
- Occupation
- Interests & hobbies
- Goals & motivations
- Personality traits
- Political/social views (if detectable)
- Subreddits frequented
- Writing style

For each item, include a **Cited Source** — a sentence from the content justifying your guess.

Reddit Data:
{input_text}
"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "You are a professional user persona analyst."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7,
    )

    return response['choices'][0]['message']['content']
